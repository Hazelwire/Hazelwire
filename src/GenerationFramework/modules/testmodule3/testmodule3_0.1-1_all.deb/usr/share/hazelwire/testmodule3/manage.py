#!/usr/bin/python

import sys

if sys.argv[1] == 'deploy':
    flag = sys.argv[2]
    f = open("/usr/share/hazelwire/testmodule3/exploit/flag.txt")
    f.write(flag)
    f.close()
