<?php
if(!isset($_FILES['file'])){
echo '<h2>Upload your pictures here!</h2>';
echo '<form action="index.php?page=upload" method="post"';
echo 'enctype="multipart/form-data">';
echo '<input type="file" name="file" id="file" />';
echo '<br />';
echo '<input type="submit" name="submit" value="Upload" />';
echo '</form>';
} else {
	if (file_exists("photos/" . $_FILES["file"]["name"]))
	{
		echo $_FILES["file"]["name"] . " already exists. ";
	}else{
		if (strpos($_FILES["file"]["name"], ".gif") !== false || strpos($_FILES["file"]["name"], ".png") !== false || strpos($_FILES["file"]["name"], ".jpg") !== false){
	      		move_uploaded_file($_FILES["file"]["tmp_name"],	"photos/" . $_FILES["file"]["name"]);
      			echo "Stored in: " . "photos/" . $_FILES["file"]["name"];
		}else{
			echo "This is not a picture! What you tring to do brah?";
		}
	}
}
?>


