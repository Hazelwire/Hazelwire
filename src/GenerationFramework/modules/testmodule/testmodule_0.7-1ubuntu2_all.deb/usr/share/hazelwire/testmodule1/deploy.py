#!/usr/bin/python

import sys

if sys.argv[1] == "deploy":
    flag = open('/var/www/testmodule/flag.txt','w')
    flag.write(sys.argv[2]+'\n')
    flag.write(sys.argv[3])
    flag.close()

