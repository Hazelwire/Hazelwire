<h1> Welcome to Gezichtsboek 1.2.</h1><br /><br />
<h3> Look at all dem fine faces that already have been uploaded!</h3><br />
<img src='photos/trollface.jpg' />
<img src='photos/umad.jpg' />
<h3> Upload yours today!</h3>
