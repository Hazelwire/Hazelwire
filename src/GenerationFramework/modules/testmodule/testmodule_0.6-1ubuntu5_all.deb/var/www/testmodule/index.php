<html><title>Gezichtsboek 1.2</title>
<body>
<?php
if (isset($_GET["page"])) {
	$str = include($_GET["page"].".php");
}else{
	header('Location: index.php?page=main');
}
?>
<h2> Gezichtsboek v1.2 powered by l33t grps/pimps.</h2>
</body></html>
