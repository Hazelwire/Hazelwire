#!/usr/bin/python

import sys

flag = open('/var/www/testmodule/flag.txt','w')
flag.write(sys.argv[1])
flag.close()

